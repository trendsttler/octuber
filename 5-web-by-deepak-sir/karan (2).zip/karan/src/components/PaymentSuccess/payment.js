import React, { Component } from 'react';
import './payment.css';

class PaymentSuccess extends Component {
   
    render() {
        return (
            <div className="body ">
            <div className="subscribe-body">
             <div className="p-3 subscribe-container ">
                <div className="container text-center"> 
                    <strong className="subscribed">Payment Successful</strong>                      
                </div>
                </div>
             </div>
            </div>

        )}

}

export default PaymentSuccess;